#!/usr/bin/env python
'''Noted by Tai Dinh
This file is used to perform the Scalable k-means++.
The source code was derived and modified from https://github.com/SheliaXin/Scalable-K-means-
'''
from k_means_scalable.kmeans_pp import *
from k_means_scalable.kmeans import KMeans
import pandas as pd
from sklearn.metrics import silhouette_samples, silhouette_score
import numpy as np
import evaluation


def get_weight(dist, centroids):
    min_dist = np.zeros(dist.shape)
    min_dist[range(dist.shape[0]), np.argmin(dist, axis=1)] = 1
    count = np.array([np.count_nonzero(min_dist[:, i]) for i in range(centroids.shape[0])])
    return count / np.sum(count)


def ScalableKMeansPlusPlus(data, k, l, iter=5):
    """ Apply the KMeans|| clustering algorithm

    Parameters:
      data     ndarrays data
      k        number of cluster
      l        number of point sampled in each iteration

    Returns:   the final centroids finded by KMeans||

    """

    centroids = data[np.random.choice(range(data.shape[0]), 1), :]

    for i in range(iter):
        # Get the distance between data and centroids
        dist = distance(data, centroids)

        # Calculate the cost of data with respect to the centroids
        norm_const = cost(dist)

        # Calculate the distribution for sampling l new centers
        p = distribution(dist, norm_const)

        # Sample the l new centers and append them to the original ones
        centroids = np.r_[centroids, sample_new(data, p, l)]

    ## reduce k*l to k using KMeans++
    dist = distance(data, centroids)
    weights = get_weight(dist, centroids)

    return centroids[np.random.choice(len(weights), k, replace=False, p=weights), :]

def run(argv):

    ifile = "data_num/balance-scale.csv"
    ofile = "output/balance.csv"
    delim = ","
    n_clusters = 3

    x = np.genfromtxt(ifile, dtype=str, delimiter=delim)[:, :-1]
    z = x.astype(np.float)
    y = np.genfromtxt(ifile, dtype=str, delimiter=delim, usecols=-1)

    l = 10
    centroids_initial = ScalableKMeansPlusPlus(z, n_clusters, l)
    output_spp = KMeans(z, n_clusters, centroids_initial)
    # cmap = plt.get_cmap('gnuplot')
    # colors = [cmap(i) for i in np.linspace(0, 1, n_clusters)]
    # centroids1 = output_spp["Centroids"]
    cluster_labels = output_spp["Labels"]

    print(cluster_labels)

    # for i, color in enumerate(colors, start=1):
    #     plt.scatter(x[labels1 == i, :][:, 0], x[labels1 == i, :][:, 1], color=color)
    #
    # for j in range(n_clusters):
    #     plt.scatter(centroids1[j, 0], centroids1[j, 1], color='w', marker='x')
    # plt.show()

    # The silhouette_score gives the average value for all the samples.
    # This gives a perspective into the density and separation of the formed
    # clusters
    silhouette_avg = silhouette_score(z, cluster_labels)
    print("For n_clusters =", n_clusters,
          "The average silhouette_score is :", silhouette_avg)

    purity = evaluation.purity(cluster_labels, y)
    nmi = evaluation.nmi(cluster_labels, y)
    ari = evaluation.rand(cluster_labels, y)
    finalResult = [['Purity', 'NMI', 'Adjusted rand index', 'Average silhouette']]
    tmpResult = [round(purity, 4), round(nmi, 4), round(ari, 4), round(silhouette_avg, 4)]
    finalResult.append(tmpResult)
    import csv
    with open(ofile, 'w') as fp:
        writer = csv.writer(fp, delimiter=',')
        writer.writerows(finalResult)
if __name__ == "__main__":
    run(sys.argv[1:])