#ifndef K_MODES_H_
#define K_MODES_H_

#include <string>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <map>
#include <algorithm>
#include <random>       // std::default_random_engine
#include <chrono>       // std::chrono::system_clock

#include "hungarian.h"
#include <stdlib.h>


using namespace std;

int* load_groundtruth(string path, string file_name, int N){

	
	int* T = new int[N];
	int i;

	//
	ifstream f(path + file_name);
	if (!f) {
		cout << "Cannot open file.\n";
		return NULL;
	}
	string line;
	i = 0;
	while (getline(f, line)){
		vector<string> items = Formatter::split(line, ',');
		T[i] = stoi(items[0]);

		i++;
	}
	f.close();

	//
	return T;
}
//// membership W, ground-truth T, both have indices in [0..K-1])
// return: C confusion matrix (row: predicted, col: actual)
void metric_confusion_matrix(int* T, int* W, int N, int K, int** ret, bool is_print){

	vector<vector<double>> C(K);
	for (int i = 0; i < K; i++)
		for (int j = 0; j < K; j++)
			C[i].push_back(0.0);

	for (int i = 0; i < N; i++)
		C[W[i]][T[i]] += 1;
	// DEBUG
	if (is_print){
		cout<<"C matrix"<<endl;
		for (int i = 0; i < K; i++){
			for (int j = 0; j < K; j++)
				cout<<C[i][j]<<"\t";
			cout<<endl;
		}
	}
	// Hungarian algo
	HungarianAlgorithm HungAlgo;
	vector<int> assignment;

	double cost = HungAlgo.Solve(C, assignment, MAX_COST);
	if (is_print){
		cout<<"assignment : ";
		for (int i = 0; i < K; i++)
			cout<<assignment[i]<<" ";
		cout<<endl;
	}

	for (int i = 0; i < K; i++)
		for (int j = 0; j < K; j++)
			ret[assignment[i]][j] = C[i][j];

	// DEBUG
//	cout<<"ret matrix 1"<<endl;
//	for (int i = 0; i < K; i++){
//		for (int j = 0; j < K; j++)
//			cout<<ret[i][j]<<"\t";
//		cout<<endl;
//	}

}

////
void print_matrix(int** C, int K){
	cout<<"Confusion matrix"<<endl;
	for (int i = 0; i < K; i++){
		for (int j = 0; j < K; j++)
			cout<<C[i][j]<<"\t";
		cout<<endl;
	}
}

//// input: confusion matrix C (row: predicted, col: actual)
// ret[0]: accuracy, ret[1]: precision, ret[2]: recall
vector<double> metric_accuracy_precision_recall(int** C, int N, int K){
	vector<double> ret;

	// accuracy
	double acc = 0.0;
	for (int i = 0; i < K; i++)
		acc += C[i][i];
	acc = acc / N;
	ret.push_back(acc);

	// precision
	double prec = 0.0;
	for (int i = 0; i < K; i++){
		double s = 0;
		for (int j = 0; j < K; j++)
			s += C[i][j];
		if (s == 0.0)
			prec += 1.0;
		else
			prec += C[i][i] / s;
	}
	prec = prec / K;
	ret.push_back(prec);

	// recall
	double rec = 0.0;
	for (int i = 0; i < K; i++){
		double s = 0;
		for (int j = 0; j < K; j++)
			s += C[j][i];
		if (s == 0.0)
			rec += 1.0;
		else
			rec += C[i][i] / s;
	}
	rec = rec / K;
	ret.push_back(rec);

	//
	return ret;
}

#endif /* K_MODES_H_ */
