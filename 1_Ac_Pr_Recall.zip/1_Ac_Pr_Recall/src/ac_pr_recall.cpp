/*
*This file is used to calculate the Accuracy, Precision and Recall of proposed algorithms.
Authour: Tai Dinh
*/

#include <string>
#include <iostream>
#include <fstream>
#include <list>
#include <vector>
#include <map>
#include <random>       // std::default_random_engine

#include "helper.h"
#include "k_modes.h"

using namespace std;

#define snprintf _snprintf


int* load_membership(string path, string file_name, int N){

	// init
	int i;
	int* X = new int[N];

	//
	ifstream f(path + file_name);
	if (!f) {
		cout << "Cannot open file.\n";
		return NULL;
	}

	//
	string line;
	i = 0;
	while (getline(f, line)){
		vector<string> items = Formatter::split(line, ',');

		for (int j = 0; j < N; j++)
		{
			int tmp = stoi(items[j]);
			X[j] = stoi(items[j]);
		}
		i++;
	}
	f.close();

	//
	return X;
}

void writeOut(float* prac, string file_name)
{
	// write to file
	ofstream fout(file_name, ofstream::out);
	for (int j = 0; j < 3; j++)
	{
		fout << prac[j] << " ";
	}
	fout.close();
}

///////////////////
int main(int argc, char* args[]) {

	int N;
	int K;
	int M;
	string membership;
	string filename;
	cout << "Input N:"<<endl;
	cin >> N;
	cout << "Input K:" << endl;
	cin >> K;
	cout << "Input membership file name:" << endl;
	cin >> membership;
	cout << "Input ground true file name:" << endl;
	cin >> filename;
	/*string path = "data\\new_data\\";*/
	string path = "data\\";
	int* X = load_membership(path, membership, N);
	////Print X
	for (int j = 0; j < N; j++)
	{
		cout << X[j] << " ";
	}
	cout << endl;
	int* GT = load_groundtruth(path,filename, N);
	cout << "Ground True:" << endl;
	for (int j = 0; j < N; j++)
	{
		cout << GT[j] << " ";
	}
	cout << endl;
	float* result = new float[3];
	int** C = new int*[K];
	for (int j = 0; j < K; j++)
		C[j] = new int[K];
	metric_confusion_matrix(GT, X, N, K, C, true);
	print_matrix(C, K);
	cout << endl;
	vector<double> ret = metric_accuracy_precision_recall(C, N, K);
	cout << "Accuracy = " << ret[0] << endl;
	cout << "Precision = " << ret[1] << endl;
	cout << "Recall = " << ret[2] << endl;
	result[0] = ret[0];
	result[1] = ret[1];
	result[2] = ret[2];
	/*for (int i = 0; i < max_inter; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << result[i][j] << " ";
		}
		cout << endl;
	}*/
	writeOut(result, "prac_" + membership);
	system("pause");
	//
	return 0;
}