#!/usr/bin/env python
# -*- coding: utf-8 -*-

'''Noted by Tai Dinh
This file is used to run the Modified 2 and Modified 3 by switching the parameter use_global_attr_count
If use_global_attr_count = 1 runs Modified 2
Otherwise runs Modified 3
The difference between the Modified 2 and Modified 3 is that the Modified 2 uses Equation 12, while the Modified 3 uses Equation 16.
'''
import sys
import getopt
import numpy as np
from kc2 import k_center2
import evaluation
from scipy import *
import pandas as pd
# For measuring the time for running program
# source: http://stackoverflow.com/a/1557906/6009280
# or https://www.w3resource.com/python-exercises/python-basic-exercise-57.php
from time import time, strftime, localtime
from datetime import timedelta
# For measuring the memory usage
import tracemalloc
from unsupervised import *
from collections import defaultdict

def _cal_global_attr_freq(X, npoints, nattrs):
    # global_attr_freq is a list of lists with dictionaries that contain the
    # frequencies of attributes.
    global_attr_freq = [defaultdict(float) for _ in range(nattrs)]

    for ipoint, curpoint in enumerate(X):
        for iattr, curattr in enumerate(curpoint):
            global_attr_freq[iattr][curattr] += 1.
    for iattr in range(nattrs):
        for key in global_attr_freq[iattr].keys():
            global_attr_freq[iattr][key] /= npoints

    return global_attr_freq

def attr_dissim(x, y, iattr, global_attr_freq):
    '''
    Dissimilarity between 2 categorical attributes x and y at the attribute iattr, i.e
    dis(x, y) = 1 - 2 * log(P{x, y}) / (log(P{x}) + log(P{y}))
    '''
    if (global_attr_freq[iattr][x] == 1.0) and (global_attr_freq[iattr][y] == 1.0):
        return 0
    if x == y:
        numerator = 2 * math.log(global_attr_freq[iattr][x])
    else:
        numerator = 2 * math.log((global_attr_freq[iattr][x] + global_attr_freq[iattr][y]))
    denominator = math.log(global_attr_freq[iattr][x]) + math.log(global_attr_freq[iattr][y]) #Noted by Tai Dinh, Equation 21, page 124
    return 1 - numerator / denominator

def pair_distance(a,b,n_attrs,global_attr_freq):
    distance = 0.
    for j in range(n_attrs):
            distance += attr_dissim(a[j], b[j], j, global_attr_freq)
    return distance

def pairwise_distances(x):
    n_samples, n_attrs = x.shape
    global_attr_freq = _cal_global_attr_freq(x, n_samples, n_attrs)
    distance = np.zeros((n_samples,n_samples))
    for row in range(n_samples):
        col = row + 1
        while col < n_samples:
            distance[row,col] = pair_distance(x[row],x[col], n_attrs,global_attr_freq)
            distance[col,row] = distance[row,col]
            col+=1
    return distance


def do_kc2(x, y, nclusters,n_init=1, verbose = 1, use_global_attr_count = 1, beta = 8):
    kc2 = k_center2.KCenterMod(n_clusters = nclusters, init='random', n_init = n_init,
        verbose = verbose, use_global_attr_count = use_global_attr_count, beta = beta)
    kc2.fit_predict(x)
    cluster_labels = kc2.labels_

    # The silhouette_score gives the average value for all the samples.
    # This gives a perspective into the density and separation of the formed
    # clusters
    _distance = pairwise_distances(x)
    sample_silhouette_values, silhouette_avg = silhouette_score(x, cluster_labels, _distance)
    print("For n_clusters =", nclusters,
          "The average silhouette_score is :", silhouette_avg)

    ari = evaluation.rand(kc2.labels_, y)
    nmi = evaluation.nmi(kc2.labels_, y)
    purity = evaluation.purity(kc2.labels_, y)
    if verbose == 1:
        print("Purity = {:8.4f}".format(purity))
        print("NMI = {:8.4f}".format(nmi))
        print("Adjusted rand index = {:8.4f}".format(ari))
        print("Average silhouettes = {:8.4f} secs".format(silhouette_avg))
        print("Finish all task!")
    tracemalloc.stop()
    return [purity, nmi, ari, silhouette_avg]

def cal_mean_value(X, indexAttr):
    # print(X.iloc[:,indexAttr])
    meanValue = mean(np.asarray(X.iloc[:,indexAttr], dtype= float))
    return round(meanValue,4)

def run(argv):
    max_iter = 100
    ifile = "data/balance-scale.csv"
    ofile = "output_kc2/balance.csv"
    use_first_column_as_label = False
    verbose = 1
    delim = ','

    # Get samples & labels
    if not use_first_column_as_label:
        x = np.genfromtxt(ifile, dtype = str, delimiter = delim)[:, :-1]
        y = np.genfromtxt(ifile, dtype = str, delimiter = delim, usecols = -1)
    else:
        x = np.genfromtxt(ifile, dtype = str, delimiter = delim)[:, 1:]
        y = np.genfromtxt(ifile, dtype = str, delimiter = delim, usecols = 0)

    from collections import Counter
    nclusters = len(list(Counter(y)))

    result = []
    for i in range(max_iter):
        if verbose:
            print("\n===============Run {0}/{1} times===============\n".format(i + 1, max_iter))
        result.append(do_kc2(x, y, nclusters))

    resultDF = pd.DataFrame(result)
    tmpResult = []
    for i in range(0, 4):
        tmpResult.append(cal_mean_value(resultDF, i))
    finalResult = [['Purity', 'NMI', 'Adjusted rand index', "Average silhouette"]]
    finalResult.append(tmpResult)
    import csv
    with open(ofile, 'w') as fp:
        writer = csv.writer(fp, delimiter=',')
        writer.writerows(finalResult)


if __name__ == "__main__":
    run(sys.argv[1:])