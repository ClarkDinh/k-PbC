#!/usr/bin/env python
'''Noted by Tai Dinh
This file is used to compute the Purity, NMI, Adjusted rand index, Average silhouette for  Khan's method 
'''
import sys
import getopt
import numpy as np
from kmodes_fold import kmodes
import evaluation
from scipy import *
import pandas as pd
# For measuring the time for running program
# source: http://stackoverflow.com/a/1557906/6009280
# or https://www.w3resource.com/python-exercises/python-basic-exercise-57.php
from time import time, strftime, localtime
from datetime import timedelta
# For measuring the memory usage
import tracemalloc
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from unsupervised import *

def matching_dissim_silhouette(a, b):
    '''Simple matching dissimilarity function'''
    return np.sum(a != b)

def pairwise_distances(x):
    n_samples, n_attrs = x.shape
    distance = np.zeros((n_samples,n_samples))
    for row in range(n_samples):
        col = row + 1
        while col < n_samples:
            distance[row,col] = matching_dissim_silhouette(x[row],x[col])
            distance[col,row] = distance[row,col]
            col+=1
    return distance

def do_kmodes(x, y, n_clusters,_distance, verbose):
    cluster_labels = array([2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,2,2,2,0,2,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,0,0,0,0,2,0,0,0,0,2,0,0,0,0,2,0,0,0,0,2,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,0,0,0,0,2,0,0,0,0,2,0,0,0,0,2,0,0,0,0,2,0,0,0,0,2,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])

    # The silhouette_score gives the average value for all the samples.
    # This gives a perspective into the density and separation of the formed
    # clusters
    sample_silhouette_values, silhouette_avg = silhouette_score(x, cluster_labels, _distance)
    print("For n_clusters =", n_clusters,
          "The average silhouette_score is :", silhouette_avg)

    ari = evaluation.rand(cluster_labels, y)
    nmi = evaluation.nmi(cluster_labels, y)
    purity = evaluation.purity(cluster_labels, y)
    # end_time = time()
    # elapsedTime = timedelta(seconds=end_time - start_time).total_seconds()
    # memoryUsage = tracemalloc.get_tracemalloc_memory() / 1024 / 1024
    if verbose == 1:
        print("Purity = {:8.4f}".format(purity))
        print("NMI = {:8.4f}".format(nmi))
        print("Adjusted rand index = {:8.4f}".format(ari))
        print("Average silhouette = {:8.4f}".format(silhouette_avg))
        # print("Memory usage = {:8.3f} MB".format(memoryUsage))
        print("Finish all tasks!")
    tracemalloc.stop()
    return [round(purity, 4), round(nmi, 4), round(ari, 4), round(silhouette_avg, 4)]


def cal_mean_value(X, indexAttr):
    # print(X.iloc[:,indexAttr])
    meanValue = mean(np.asarray(X.iloc[:, indexAttr], dtype=float))
    return meanValue

def run(argv):
    max_iter = 1
    ifile = "data/balance-scale.csv"
    ofile = "output_khan/balance.csv"
    use_first_column_as_label = False
    verbose = 1
    delim = ","
    n_init = 1

    # Get samples & labels
    if not use_first_column_as_label:
        x = np.genfromtxt(ifile, dtype = str, delimiter = delim)[:, :-1]
        y = np.genfromtxt(ifile, dtype = str, delimiter = delim, usecols = -1)
    else:
        x = np.genfromtxt(ifile, dtype = str, delimiter = delim)[:, 1:]
        y = np.genfromtxt(ifile, dtype = str, delimiter = delim, usecols = 0)

    from collections import Counter
    n_clusters = len(list(Counter(y)))
    _distance = pairwise_distances(x)

    result = []
    for i in range(max_iter):
        if verbose:
            print("\n===============Run {0}/{1} times===============\n".format(i + 1, max_iter))
        result.append(do_kmodes(x, y, n_clusters,_distance,verbose))

    resultDF = pd.DataFrame(result)
    tmpResult = []
    for i in range(0, 4):
        tmpResult.append(cal_mean_value(resultDF, i))
    finalResult = [['Purity', 'NMI', 'Adjusted rand index', "Average silhouette"]]
    finalResult.append(tmpResult)
    import csv
    with open(ofile, 'w') as fp:
        writer = csv.writer(fp, delimiter=',')
        writer.writerows(finalResult)

if __name__ == "__main__":
    run(sys.argv[1:])