/*
*This file is used to calculate the Accuracy, Precision and Recall of proposed algorithms.
Authour: Tai Dinh
*/

#include <string>
#include <iostream>
#include <fstream>
#include <list>
#include <vector>
#include <map>
#include <random>       // std::default_random_engine

#include "helper.h"
#include "k_modes.h"

using namespace std;

#define snprintf _snprintf


int** load_membership(string path, string file_name, int N, int max_inter){

	// init
	int i;
	int** X = new int*[max_inter];
	for (i = 0; i < max_inter; i++)
		X[i] = new int[N];

	//
	ifstream f(path + file_name);
	if (!f) {
		cout << "Cannot open file.\n";
		return NULL;
	}

	//
	string line;
	i = 0;
	while (getline(f, line)){
		vector<string> items = Formatter::split(line, ',');

		for (int j = 0; j < N; j++)
			X[i][j] = stoi(items[j]);
		i++;
	}
	f.close();

	//
	return X;
}

void writeOut(float** prac, int max_inter, string file_name)
{
	// write to file
	ofstream fout(file_name, ofstream::out);
	for (int k = 0; k < max_inter; k++)
	{
		for (int j = 0; j < 3; j++)
		{
			fout << prac[k][j] << " ";
		}
		fout << endl;
	}

	fout.close();
}

///////////////////
int main(int argc, char* args[]) {

	int N;
	int K;
	int M;
	int max_inter = 100;
	string membership;
	string filename;
	cout << "Input N:"<<endl;
	cin >> N;
	cout << "Input K:" << endl;
	cin >> K;
	cout << "Input Membership File name:" << endl;
	cin >> membership;
	cout << "Data File name:" << endl;
	cin >> filename;
	/*string path = "data\\new_data\\";*/
	string path = "data\\";
	int** X = load_membership(path, membership, N, max_inter);
	////Print X
	//for (int i = 0; i < max_inter; i++)
	//{
	//	for (int j = 0; j < N; j++)
	//	{
	//		cout << X[i][j] << " ";
	//	}
	//	cout << endl;
	//}

	int* GT = load_groundtruth(path,filename, N);
	/*cout << "Ground True:" << endl;
	for (int j = 0; j < N; j++)
	{
		cout << GT[j] << " ";
	}
	cout << endl;*/
	float **result = new float*[max_inter];
	for (int k = 0; k < max_inter; k++)
	{
		result[k] = new float[3];
	}
	for (int i = 0; i < max_inter; i++)
	{
		cout << "Run: "<<i + 1<<endl;
		int* W = X[i];
		int** C = new int*[K];
		for (int j = 0; j < K; j++)
			C[j] = new int[K];
		metric_confusion_matrix(GT, W, N, K, C, true);
		print_matrix(C, K);
		cout << endl;
		vector<double> ret = metric_accuracy_precision_recall(C, N, K);
		cout << "Accuracy = " << ret[0] << endl;
		cout << "Precision = " << ret[1] << endl;
		cout << "Recall = " << ret[2] << endl;
		result[i][0] = ret[0];
		result[i][1] = ret[1];
		result[i][2] = ret[2];
	}
	/*for (int i = 0; i < max_inter; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << result[i][j] << " ";
		}
		cout << endl;
	}*/
	writeOut(result, max_inter, "prac_" + membership);
	system("pause");
	//
	return 0;
}